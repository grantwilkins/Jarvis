Showcase
========

Demonstrate all the possibilities of Kivy toolkit.

Android
-------

You can copy/paste this directory into /sdcard/kivy/showcase in your
android device.

