#!/bin/bash

export SDL2="release-2.0.20"
export SDL2_IMAGE="168ceb577c245c91801c1bcaf970ef31c9b4d7ba"
export SDL2_MIXER="64120a41f62310a8be9bb97116e15a95a892e39d"
export SDL2_TTF="release-2.0.18"
export PLATYPUS=5.3
